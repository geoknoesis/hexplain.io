package io.hexplain.core.raster
import com.google.gson.Gson
import com.google.gson.JsonParser
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.DynamicTest
import org.junit.jupiter.api.TestFactory
import java.util.Base64
import java.security.MessageDigest
class GdalVectorGeometryTest {
    @TestFactory fun `all ISO geometry families and dimensions agree with GDAL`() =
        JsonParser.parseString(javaClass.getResourceAsStream("/gdal-vector-geometry.json")!!.bufferedReader().use { it.readText() }).asJsonObject["cases"].asJsonArray.map { item ->
            val c=item.asJsonObject
            DynamicTest.dynamicTest(c["name"].asString) {
                val bytes=Base64.getDecoder().decode(c["base64"].asString)
                assertEquals(c["sha256"].asString,MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) })
                assertEquals(c["expected"],Gson().toJsonTree(GeometryDecoder().wkb(bytes)))
            }
        }
}
