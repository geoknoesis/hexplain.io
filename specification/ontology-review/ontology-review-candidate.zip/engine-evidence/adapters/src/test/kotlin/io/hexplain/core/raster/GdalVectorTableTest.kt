package io.hexplain.core.raster
import com.google.gson.Gson
import com.google.gson.JsonParser
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.DynamicTest
import org.junit.jupiter.api.TestFactory
import org.junit.jupiter.api.io.TempDir
import java.nio.file.Path
import java.nio.file.Files
import java.util.Base64
import java.security.MessageDigest
class GdalVectorTableTest {
    @TempDir lateinit var root: Path
    @TestFactory fun `GeoPackage dimensions nulls CRS and exact attributes agree with GDAL`(): List<DynamicTest> {
        val corpus=JsonParser.parseString(javaClass.getResourceAsStream("/gdal-vector-geometry.json")!!.bufferedReader().use { it.readText() }).asJsonObject["geopackage"].asJsonObject
        return corpus["tables"].asJsonArray.map { item ->
            val expected=item.asJsonObject
            DynamicTest.dynamicTest(expected["name"].asString) {
                val bytes=Base64.getDecoder().decode(corpus["base64"].asString)
                assertEquals(corpus["sha256"].asString,MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) })
                val file=root.resolve(expected["name"].asString+".gpkg");Files.write(file,bytes)
                val actual=TabularDecoder().geoPackage(file,expected["name"].asString)
                assertEquals(expected["srs"].asInt,actual.srsId)
                val names=actual.table.columns.map { it.name }
                assertEquals("geom",actual.geometryColumn)
                val rows=actual.table.rows.sortedBy { (it[names.indexOf("fid")] as Number).toLong() }
                assertEquals(expected["rows"].asJsonArray.size(),rows.size)
                rows.forEachIndexed { i,row ->
                    val e=expected["rows"].asJsonArray[i].asJsonObject
                    assertEquals(e["fid"].asLong,(row[names.indexOf("fid")] as Number).toLong())
                    assertEquals(e["large_id"].asLong,(row[names.indexOf("large_id")] as Number).toLong())
                    assertEquals(if(e["label"].isJsonNull) null else e["label"].asString,row[names.indexOf("label")])
                    val g=row[names.indexOf("geom")] as GeoPackageGeometry?
                    if(e["geometry"].isJsonNull) assertNull(g)
                    else { assertNotNull(g);assertEquals(actual.srsId,g!!.srsId);assertEquals(e["geometry"],Gson().toJsonTree(g.geometry)) }
                }
                assertArrayEquals(bytes,Files.readAllBytes(file))
            }
        }
    }
}
