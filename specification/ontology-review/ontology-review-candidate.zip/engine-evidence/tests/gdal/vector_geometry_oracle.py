"""Pinned GDAL ISO-WKB oracle; generated geometry coverage, not native driver coverage."""
from pathlib import Path
from osgeo import ogr,gdal,osr
import tempfile
import json,base64,hashlib
ogr.UseExceptions()
OUT=Path(__file__).resolve().parent/'results/vector-geometry.json'
def value(g):
    kind=ogr.GT_Flatten(g.GetGeometryType())
    if kind==ogr.wkbLinearRing:kind=2
    dims='XY'+('Z' if g.Is3D() else '')+('M' if g.IsMeasured() else '')
    coords=[]
    if kind in (1,2) and not g.IsEmpty():
        for i in range(g.GetPointCount()):
            p=[g.GetX(i),g.GetY(i)]
            if g.Is3D():p.append(g.GetZ(i))
            if g.IsMeasured():p.append(g.GetM(i))
            coords.append(p)
    return dict(type=kind,dimensions=dims,coordinates=coords,children=[value(g.GetGeometryRef(i)) for i in range(g.GetGeometryCount())])
cases=[]
for dim in ['', 'Z','M','ZM']:
    def point(x,y):return ' '.join(map(str,[x,y]+([3] if 'Z' in dim else [])+([7] if 'M' in dim else [])))
    a,b,c,d=point(-1,2),point(4,2),point(4,8),point(-1,2)
    line=f'{a},{b}'
    ring=f'{a},{b},{c},{d}'
    wkts=[f'POINT {dim} ({a})',f'LINESTRING {dim} ({line})',f'POLYGON {dim} (({ring}))',f'MULTIPOINT {dim} (({a}),({b}))',f'MULTILINESTRING {dim} (({line}),({b},{c}))',f'MULTIPOLYGON {dim} ((({ring})))',f'GEOMETRYCOLLECTION {dim} (POINT {dim} ({a}),LINESTRING {dim} ({line}))']
    wkts += [f'{name} {dim} EMPTY' for name in ['POINT','LINESTRING','POLYGON','MULTIPOINT','MULTILINESTRING','MULTIPOLYGON','GEOMETRYCOLLECTION']]
    for index,wkt in enumerate(wkts):
        g=ogr.CreateGeometryFromWkt(wkt)
        for order in [ogr.wkbXDR,ogr.wkbNDR]:
            raw=bytes(g.ExportToIsoWkb(order))
            reread=ogr.CreateGeometryFromWkb(raw)
            assert value(g)==value(reread)
            cases.append(dict(name=f'{dim or "XY"}-{index}-{order}',wkt=wkt,sha256=hashlib.sha256(raw).hexdigest(),base64=base64.b64encode(raw).decode(),expected=value(g)))
# Actual GeoPackage storage and reopening, independent of Hexplain's SQLite reader.
with tempfile.TemporaryDirectory() as tmp:
    file=Path(tmp)/'vectors.gpkg'
    ds=ogr.GetDriverByName('GPKG').CreateDataSource(str(file))
    srs=osr.SpatialReference();srs.ImportFromEPSG(4326)
    for dim in ['XY','Z','M','ZM']:
        kind=ogr.wkbUnknown
        if 'Z' in dim:kind=ogr.GT_SetZ(kind)
        if 'M' in dim:kind=ogr.GT_SetM(kind)
        layer=ds.CreateLayer(dim,srs,kind,options=['GEOMETRY_NAME=geom','SPATIAL_INDEX=NO'])
        layer.CreateField(ogr.FieldDefn('label',ogr.OFTString))
        layer.CreateField(ogr.FieldDefn('large_id',ogr.OFTInteger64))
        selected=[c for c in cases if c['name'].startswith(dim+'-') and c['name'].endswith('-1')]
        assert len(selected)==14
        for i,c in enumerate(selected+[None]):
            f=ogr.Feature(layer.GetLayerDefn());f.SetFID(i+1)
            if i % 2 == 0:f.SetField('label','feature-'+str(i))
            f.SetField('large_id',9007199254740993+i)
            if c is not None:f.SetGeometry(ogr.CreateGeometryFromWkt(c['wkt']))
            assert layer.CreateFeature(f)==0
        layer=None
    ds=None
    ds=ogr.Open(str(file));tables=[]
    for layer in ds:
        rows=[]
        for f in layer:
            g=f.GetGeometryRef()
            rows.append(dict(fid=f.GetFID(),label=f.GetField('label'),large_id=f.GetFieldAsInteger64('large_id'),geometry=value(g) if g is not None else None))
        tables.append(dict(name=layer.GetName(),srs=int(layer.GetSpatialRef().GetAuthorityCode(None)),rows=rows))
    ds=None
    raw=file.read_bytes()
    package=dict(base64=base64.b64encode(raw).decode(),sha256=hashlib.sha256(raw).hexdigest(),tables=tables)
OUT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_text(json.dumps(dict(gdal=gdal.VersionInfo('--version'),scope='Generated ISO WKB types 1-7, XY/XYZ/XYM/XYZM, empty/nonempty, both byte orders; no CRS transformation or native container claim',cases=cases,geopackage=package),indent=2)+'\n',encoding='utf-8')
print(f'PASS: {len(cases)} GDAL geometry oracle cases')
