"""Read-only publication acceptance; a successful HTML fallback is a failure."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request
from rdflib import Graph
from rdflib.compare import isomorphic

root=Path(__file__).resolve().parents[1]
cases=[('https://hexplain.io/ns/aspect/security','text/turtle',root/'specification/aspect/security/security.ttl'),
       ('https://hexplain.io/releases/2026-09-05.1/manifest.json','application/json',root/'releases/2026-09-05.1/manifest.json')]
results=[]
for url,media,file in cases:
    row=dict(url=url,expected_media_type=media,passed=False)
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'Accept':media}),timeout=15) as response:
            row.update(status=response.status,media_type=response.headers.get_content_type(),final_url=response.url)
            body=response.read(4*1024*1024+1)
        if len(body)>4*1024*1024:raise ValueError('Response exceeds publication check limit')
        row['response_sha256']=hashlib.sha256(body).hexdigest()
        if row['media_type']!=media:raise ValueError('Incorrect negotiated media type; possible HTML fallback')
        if media=='application/json':
            if json.loads(body)!=json.loads(file.read_text(encoding='utf-8')):raise ValueError('Published manifest differs from local immutable snapshot')
        elif not isomorphic(Graph().parse(data=body,format='turtle'),Graph().parse(file,format='turtle')):
            raise ValueError('Published RDF differs from canonical graph')
        row['passed']=True
    except Exception as error:row['error']=str(error)
    results.append(row)
out=root/'review-2026-09-05/live-publication.json'
out.write_text(json.dumps(dict(checked_at=datetime.now(timezone.utc).isoformat(),checks=results),indent=2)+'\n',encoding='utf-8')
print(json.dumps(results,indent=2))
raise SystemExit(0 if all(r['passed'] for r in results) else 1)
