"""Verify archive integrity; historical compatibility replay is explicitly opt-in."""
import argparse
import base64
from pyshacl import validate
from rdflib import Namespace, URIRef
import hashlib
import json
import zipfile
from pathlib import Path
from rdflib import Graph
import specgraph


current_files = {p: Path(p).read_text(encoding='utf-8') for p in specgraph.ontology_paths()}
current = specgraph.ontologies()
parser=argparse.ArgumentParser()
parser.add_argument('--release', help='Replay only this existing release identifier')
parser.add_argument('--replay-history', action='store_true', help='Optional historical compatibility audit; not a prerelease gate')
args=parser.parse_args()
if args.replay_history:
    from test_instance_contract import check_corpus
releases = sorted(Path('releases').glob('*/manifest.json'))
if args.release: releases=[p for p in releases if p.parent.name==args.release]
assert releases, 'No pinned specification snapshot'
cases = 0
for path in releases:
    manifest = json.loads(path.read_text(encoding='utf-8'))
    assert manifest['releaseId'] == path.parent.name
    archive = path.parent / manifest['archive']
    assert archive.parent == path.parent and archive.name == 'hexplain-spec.zip'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['sha256'], archive
    files = {}
    family = Graph()
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist()) == len(set(z.namelist()))
        assert sorted(z.namelist()) == sorted(f['path'] for f in manifest['files'])
        for item in manifest['files']:
            data = z.read(item['path'])
            assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
            files[item['path']] = data.decode('utf-8')
            if item['path'].endswith('.ttl'):
                family.parse(data=data, format='turtle')
    if not args.replay_history:
        continue
    corpus = files['specification/validation/test/competency.tsv']
    archived_count = check_corpus(family, files, corpus)
    assert check_corpus(current, current_files, corpus) == archived_count
    cases += archived_count
    for corpus_name, shape_paths in [
        ('layout-competency.tsv',['specification/dlv/dlv.ttl','specification/aspect/bundle/bundle.ttl']),
        ('security-competency.tsv',['specification/validation/test/security-profile.ttl']),
        ('geometry-competency.tsv',['specification/aspect/geometry/geometry.ttl']),
        ('network-competency.tsv',['specification/npv/net.ttl']),
        ('spatialref-competency.tsv',['specification/aspect/spatialref/spatialref.ttl']),
        ('core-mapping-competency.tsv',['specification/hexplain/core.ttl']),
        ('conformance-competency.tsv',['specification/conf/conf.ttl','specification/conf/shapes.ttl','specification/req/req.ttl','specification/req/shapes.ttl','specification/fn/fn.ttl'])]:
        corpus_path='specification/validation/test/'+corpus_name
        if corpus_path not in files: continue  # Older immutable releases predate these suites.
        for archived in [True,False]:
            selected=Graph()
            for shape_path in shape_paths:
                selected.parse(data=files[shape_path] if archived else Path(shape_path).read_text(encoding='utf-8'),format='turtle')
            for row in files[corpus_path].splitlines():
                if not row or row.startswith('#'):continue
                name,expected,result_path,encoded=row.split('\t')
                ok,report,detail=validate(Graph().parse(data=base64.b64decode(encoded).decode(),format='turtle'),shacl_graph=selected,inference='none',advanced=False)
                assert bool(ok)==(expected=='true'),(path,name,archived,detail)
                if result_path:assert URIRef(result_path) in report.objects(None,Namespace('http://www.w3.org/ns/shacl#').resultPath),(name,detail)
        cases += sum(bool(row) and not row.startswith('#') for row in files[corpus_path].splitlines())
    family_path='specification/validation/test/family-contracts.json'
    if family_path in files:
        retained=json.loads(files[family_path])
        for archived in [True,False]:
            selected={}
            for row in retained:
                module=row['module']
                if module not in selected:
                    selected[module]=Graph().parse(data=files[module] if archived else Path(module).read_text(encoding='utf-8'),format='turtle')
                case_shapes=selected[module]
                if row.get('targetShape'):
                    case_shapes=Graph()+case_shapes
                    case_shapes.add((URIRef(row['targetShape']),Namespace('http://www.w3.org/ns/shacl#').targetNode,URIRef(row['targetNode'])))
                ok,report,detail=validate(Graph().parse(data=row['data'],format='turtle'),shacl_graph=case_shapes,inference='none')
                assert bool(ok)==row['expected'],(path,row['name'],archived,detail)
                sh=Namespace('http://www.w3.org/ns/shacl#')
                if row['path']:assert URIRef(row['path']) in report.objects(None,sh.resultPath),(row['name'],detail)
                if row.get('expectedShape'):assert URIRef(row['expectedShape']) in report.objects(None,sh.sourceShape),(row['name'],detail)
        cases+=len(retained)
print(f'PASS: {len(releases)} immutable snapshots verified; historical compatibility replay ' + (f'{cases} cases' if args.replay_history else 'not requested (prerelease)'))
